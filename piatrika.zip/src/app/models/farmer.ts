export class Farmer {
    id:number;
    csi_code:number;
    rno:string;
    sysno:string;
    village_id:number;
    csi_name:string;
    litrary_status:string;
    city:string;
    person_id:number;
    ryot_photo:string;
    latitude:number;
    longitude:number;
    LatLng:string;
}
