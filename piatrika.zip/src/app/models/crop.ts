export class Crop {
    id:number;
    crop_name:string;
    crop_scientific_name:string;
}
