export class FarmerBank {
    id:number;
    account_no:string;
    Farmers_id:number;
    bank_id:number;
}
