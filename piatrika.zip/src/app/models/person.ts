export class Person {
    id:number;
    first_name:string;
    middle_name:string;
    last_name:string;
    address:string;
    city:string;
    email:string;
}
