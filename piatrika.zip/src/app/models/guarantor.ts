export class Guarantor {
    id:number;
    season_id:number;
    season_Farmers_id:number;
    season_land_village_id:number;
    person_id:number;
}
