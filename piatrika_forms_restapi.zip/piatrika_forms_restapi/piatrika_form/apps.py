from django.apps import AppConfig


class PiatrikaFormConfig(AppConfig):
    name = 'piatrika_form'
